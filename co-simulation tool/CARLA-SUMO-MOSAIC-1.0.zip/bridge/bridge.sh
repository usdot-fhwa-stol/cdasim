#!/bin/bash

#x-terminal-emulator

python3 carla_mosaic_bridge.py --bridge-server-port 8913 --map Town04 net/Town04.net.xml


