#!/bin/bash

x-terminal-emulator


python3 carla_mosaic_bridge.py --bridge-server-port 8913


