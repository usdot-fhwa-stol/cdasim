#!/bin/bash

#x-terminal-emulator
cd ../../../bridge

# x-terminal-emulator -e
x-terminal-emulator -e python3.7 carla_mosaic_bridge.py --bridge-server-port 8913 -m Town04 net/Town04.net.xml --tls-manager sumo
