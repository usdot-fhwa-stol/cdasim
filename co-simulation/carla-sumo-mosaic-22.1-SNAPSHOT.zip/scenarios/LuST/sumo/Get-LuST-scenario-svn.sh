#!/bin/bash

svn checkout https://github.com/lcodeca/LuSTScenario.git/trunk ./LuSTScenario
